Họ Và Tên: Trần Văn Điệp
MSSV: 1712343
Buổi: Thứ 2

Mô tả:
	file main12.m để chạy các file của câu 12: saiSo2Bien, saiSo3Bien, saiSoNBien, layGiaTri, laySaiSo
	File main13.m để chạy các file của câu 13: hamCauA, hamCauB, hamCauC, hamCauD, lamtron