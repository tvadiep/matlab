# matlab
# Homework week 5
# Name: Tran Van Diep
# SID : 1712343
### Date: April 20, 2021