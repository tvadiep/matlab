### Họ Và Tên: Trần Văn Điệp <br>
### MSSV: 1712343<br>
### Lớp: Thực hành sáng thứ 2 ca 2<br>
#### Link matlab: https://github.com/tvadiep/matlab/new/main/Buoi7
